window.addEvent('domready', function(){ 
	var myscrollGallery = new scrollGallery(); 
});